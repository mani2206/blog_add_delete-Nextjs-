// 'use client';
// import { Dispatch, SetStateAction } from 'react';

// interface FiltersProps {
//   selectedCategories: string[];
//   setSelectedCategories: Dispatch<SetStateAction<string[]>>;
//   selectedTags: string[];
//   setSelectedTags: Dispatch<SetStateAction<string[]>>;
//   selectedAuthor: string;
//   setSelectedAuthor: Dispatch<SetStateAction<string>>;
//   sortValue: string;
//   setSortValue: Dispatch<SetStateAction<string>>;
// }

// export default function Filters({
//   selectedCategories,
//   setSelectedCategories,
//   selectedTags,
//   setSelectedTags,
//   selectedAuthor,
//   setSelectedAuthor,
//   sortValue,
//   setSortValue,
// }: FiltersProps) {
//   const handleMultiSelectChange = (
//     e: React.ChangeEvent<HTMLSelectElement>,
//     setState: Dispatch<SetStateAction<string[]>>,
//   ) => {
//     const options = Array.from(e.target.selectedOptions).map((option) => option.value);
//     setState(options);
//   };

//   return (
//     <div className="bg-white p-6 rounded-lg shadow-md mb-6">
//       <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
//         {/* Category Filter */}
//         <div>
//           <label className="block text-sm font-medium text-gray-700 mb-2">Categories</label>
//           <select
//             multiple
//             className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
//             value={selectedCategories}
//             onChange={(e) => handleMultiSelectChange(e, setSelectedCategories)}
//           >
//             <option value="tech">Tech</option>
//             <option value="lifestyle">Lifestyle</option>
//             <option value="travel">Travel</option>
//             <option value="food">Food</option>
//           </select>
//         </div>

//         {/* Tags Filter */}
//         <div>
//           <label className="block text-sm font-medium text-gray-700 mb-2">Tags</label>
//           <select
//             multiple
//             className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
//             value={selectedTags}
//             onChange={(e) => handleMultiSelectChange(e, setSelectedTags)}
//           >
//             <option value="javascript">JavaScript</option>
//             <option value="react">React</option>
//             <option value="nextjs">Next.js</option>
//             <option value="webdev">Web Dev</option>
//           </select>
//         </div>

//         {/* Author Filter */}
//         <div>
//           <label className="block text-sm font-medium text-gray-700 mb-2">Author</label>
//           <select
//             className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
//             value={selectedAuthor}
//             onChange={(e) => setSelectedAuthor(e.target.value)}
//           >
//             <option value="">All Authors</option>
//             <option value="john">John Doe</option>
//             <option value="jane">Jane Smith</option>
//             <option value="bob">Bob Johnson</option>
//           </select>
//         </div>

//         {/* Sort Filter */}
//         <div>
//           <label className="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
//           <select
//             className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
//             value={sortValue}
//             onChange={(e) => setSortValue(e.target.value)}
//           >
//             <option value="date-desc">Date (Newest First)</option>
//             <option value="date-asc">Date (Oldest First)</option>
//             <option value="title-asc">Alphabetical (A-Z)</option>
//             <option value="title-desc">Alphabetical (Z-A)</option>
//           </select>
//         </div>
//       </div>
//     </div>
//   );
// }

"use client";

import { Dispatch, SetStateAction } from "react";

interface FiltersProps {
  categories: { id: number; name: string }[];
  tags: { id: number; name: string }[];
  authors: { id: number; name: string }[];
  selectedCategories: string[];
  setSelectedCategories: Dispatch<SetStateAction<string[]>>;
  selectedTags: string[];
  setSelectedTags: Dispatch<SetStateAction<string[]>>;
  selectedAuthor: string;
  setSelectedAuthor: Dispatch<SetStateAction<string>>;
  sortValue: string;
  setSortValue: Dispatch<SetStateAction<string>>;
}

export default function Filters({
  //   categories,
  //   tags,
  //   authors,
  //   selectedCategories,
  //   setSelectedCategories,
  //   selectedTags,
  //   setSelectedTags,
  //   selectedAuthor,
  //   setSelectedAuthor,
  //   sortValue,
  //   setSortValue,
  categories = [],
  tags = [],
  authors = [],
  selectedCategories,
  setSelectedCategories,
  selectedTags,
  setSelectedTags,
  selectedAuthor,
  setSelectedAuthor,
  sortValue,
  setSortValue,
}: FiltersProps) {
  const handleMultiSelectChange = (
    e: React.ChangeEvent<HTMLSelectElement>,
    setState: Dispatch<SetStateAction<string[]>>
  ) => {
    const options = Array.from(e.target.selectedOptions).map(
      (option) => option.value
    );
    setState(options);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Category Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Categories
          </label>
          <select
            multiple
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
            value={selectedCategories}
            onChange={(e) => handleMultiSelectChange(e, setSelectedCategories)}
          >
            {categories.map((category) => (
              <option key={category.id} value={category.id.toString()}>
                {category.name}
              </option>
            ))}
          </select>
        </div>

        {/* Tags Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Tags
          </label>
          <select
            multiple
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
            value={selectedTags}
            onChange={(e) => handleMultiSelectChange(e, setSelectedTags)}
          >
            {tags.map((tag) => (
              <option key={tag.id} value={tag.id.toString()}>
                {tag.name}
              </option>
            ))}
          </select>
        </div>

        {/* Author Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Author
          </label>
          <select
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
            value={selectedAuthor}
            onChange={(e) => setSelectedAuthor(e.target.value)}
          >
            <option value="">All Authors</option>
            {authors.map((author) => (
              <option key={author.id} value={author.id.toString()}>
                {author.name}
              </option>
            ))}
          </select>
        </div>

        {/* Sort Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Sort By
          </label>
          <select
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
            value={sortValue}
            onChange={(e) => setSortValue(e.target.value)}
          >
            <option value="date-desc">Date (Newest First)</option>
            <option value="date-asc">Date (Oldest First)</option>
            <option value="title-asc">Alphabetical (A-Z)</option>
            <option value="title-desc">Alphabetical (Z-A)</option>
          </select>
        </div>
      </div>
    </div>
  );
}
