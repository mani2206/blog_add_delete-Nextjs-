// 'use client';
// import { BlogPost } from '../lib/data';


// interface PostCardProps {
//   post: BlogPost;
// }

// export default function PostCard({ post }: PostCardProps) {
//   const getExcerpt = (content: string) => {
//     const words = content.split(' ');
//     return words.slice(0, 30).join(' ') + (words.length > 30 ? '...' : '');
//   };

//   return (
//     <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
//       <img src={post.image} alt={post.title} className="w-full h-48 object-cover" />
//       <div className="p-6">
//         <h2 className="text-xl font-semibold text-gray-800 mb-2">{post.title}</h2>
//         <p className="text-gray-600 mb-4">{getExcerpt(post.content)}</p>
//         <div className="flex flex-wrap gap-2 mb-4">
//           {post.categories.map((cat) => (
//             <span key={cat} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
//               {cat}
//             </span>
//           ))}
//         </div>
//         <div className="flex flex-wrap gap-2 mb-4">
//           {post.tags.map((tag) => (
//             <span key={tag} className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">
//               {tag}
//             </span>
//           ))}
//         </div>
//         <div className="flex justify-between items-center text-sm text-gray-500">
//           <span>By {post.authorName}</span>
//           <span>{new Date(post.date).toLocaleDateString()}</span>
//         </div>
//       </div>
//     </div>
//   );
// }


// 'use client';

// import { BlogPost } from '../lib/utils';

// interface PostCardProps {
//   post: BlogPost;
//   onDelete: (postId: number) => void;
// }

// export default function PostCard({ post, onDelete }: PostCardProps) {
//   const getExcerpt = (content: string) => {
//     const words = content.split(' ');
//     return words.slice(0, 30).join(' ') + (words.length > 30 ? '...' : '');
//   };

//   return (
//     <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
//       <img src={post.image} alt={post.title} className="w-full h-48 object-cover" />
//       <div className="p-6">
//         <h2 className="text-xl font-semibold text-gray-800 mb-2">{post.title}</h2>
//         <p className="text-gray-600 mb-4">{getExcerpt(post.content)}</p>
//         <div className="flex flex-wrap gap-2 mb-4">
//           {post.category ? (
//             <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">{post.category.name}</span>
//           ) : null}
//         </div>
//         <div className="flex flex-wrap gap-2 mb-4">
//           {post.tags.map((tag) => (
//             <span key={tag.id} className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">
//               {tag.name}
//             </span>
//           ))}
//         </div>
//         <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
//            <span>By {post.author?.name ?? "Unknown Author"}</span>
//           <span>{new Date(post.date).toLocaleDateString()}</span>
//         </div>
//         <button
//           onClick={() => onDelete(post.id)}
//           className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition"
//         >
//           Delete
//         </button>
//       </div>
//     </div>
//   );
// }


'use client';

import { BlogPost } from '../lib/utils';

interface PostCardProps {
  post: BlogPost;
  onDelete: (postId: number) => void;
}

export default function PostCard({ post, onDelete }: PostCardProps) {
  const getExcerpt = (content: string) => {
    const words = content.split(' ');
    return words.slice(0, 30).join(' ') + (words.length > 30 ? '...' : '');
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <img src={post.image} alt={post.title} className="w-full h-48 object-cover" />
      <div className="p-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-2">{post.title}</h2>
        <p className="text-gray-600 mb-4">{getExcerpt(post.content)}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {post.category ? (
            <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">{post.category.name}</span>
          ) : null}
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {post.tags.map((tag) => (
            <span key={tag.id} className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">
              {tag.name}
            </span>
          ))}
        </div>
        <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
          <span>By {post.author.name}</span>
          <span>{new Date(post.date).toLocaleDateString()}</span>
        </div>
        <button
          onClick={() => onDelete(post.id)}
          className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition"
        >
          Delete
        </button>
      </div>
    </div>
  );
}