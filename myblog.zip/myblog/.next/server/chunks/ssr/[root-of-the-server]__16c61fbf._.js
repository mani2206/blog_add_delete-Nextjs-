module.exports = [
"[project]/.next-internal/server/app/blog/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/blog/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

// "use"
// import { useState } from 'react';
// import SearchBar from '@/components/SearchBar';
// import Filters from '../../components/Filters';
// import PostGrid from '../../components/PostGrid';
// import { BlogPost, filterAndSortPosts } from '../../lib/utils';
// import { blogPosts } from '../../lib/data';
// export default function BlogPage() {
//   const [searchTerm, setSearchTerm] = useState('');
//   const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
//   const [selectedTags, setSelectedTags] = useState<string[]>([]);
//   const [selectedAuthor, setSelectedAuthor] = useState('');
//   const [sortValue, setSortValue] = useState('date-desc');
//   const filteredPosts = filterAndSortPosts(blogPosts, {
//     searchTerm,
//     selectedCategories,
//     selectedTags,
//     selectedAuthor,
//     sortValue,
//   });
//   return (
//     <div className="container mx-auto px-4">
//       <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">Blog Posts</h1>
//       <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
//       <Filters
//         selectedCategories={selectedCategories}
//         setSelectedCategories={setSelectedCategories}
//         selectedTags={selectedTags}
//         setSelectedTags={setSelectedTags}
//         selectedAuthor={selectedAuthor}
//         setSelectedAuthor={setSelectedAuthor}
//         sortValue={sortValue}
//         setSortValue={setSortValue}
//       />
//       <PostGrid posts={filteredPosts} />
//     </div>
//   );
// }
}),
"[project]/app/blog/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/blog/page.tsx [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__16c61fbf._.js.map